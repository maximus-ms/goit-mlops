def handler(event, context):
    print("📈 Logging metrics to MLflow...")
    return {"status": "logged"}
