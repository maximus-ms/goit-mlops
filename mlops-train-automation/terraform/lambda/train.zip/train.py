def handler(event, context):
    print("🚀 Training model...")
    return {"status": "trained"}